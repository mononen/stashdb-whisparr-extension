// Create context menu item when extension is installed
browser.runtime.onInstalled.addListener(() => {
  browser.contextMenus.create({
    id: "add-to-whisparr",
    title: "Add to Whisparr",
    contexts: ["page"],
    documentUrlPatterns: ["*://stashdb.org/scenes/*"]
  });
});

// Handle context menu click
browser.contextMenus.onClicked.addListener(async (info, tab) => {
  console.log("[StashDB-Whisparr] Context menu clicked:", info.menuItemId);
  
  if (info.menuItemId === "add-to-whisparr") {
    const stashId = extractStashId(tab.url);
    console.log("[StashDB-Whisparr] Extracted stashId:", stashId, "from URL:", tab.url);
    
    if (!stashId) {
      showNotification("Error", "Could not extract StashID from URL");
      return;
    }

    try {
      const result = await addSceneToWhisparr(stashId);
      console.log("[StashDB-Whisparr] Result:", result);
      
      // Check if this was an existing scene that we triggered a search for
      if (result && result.searched) {
        showNotification("Searching", `Scene already in Whisparr - search triggered`);
      } else {
        showNotification("Success", `Scene added to Whisparr`);
      }
    } catch (error) {
      console.error("[StashDB-Whisparr] Error:", error);
      showNotification("Error", error.message);
    }
  }
});

// Extract StashID (UUID) from URL
function extractStashId(url) {
  const match = url.match(/stashdb\.org\/scenes\/([a-f0-9-]+)/i);
  return match ? match[1] : null;
}

// Get settings from storage
async function getSettings() {
  const defaults = {
    whisparrUrl: "",
    apiKey: "",
    rootFolderPath: "",
    qualityProfileId: 1,
    searchForMovie: true,
    monitored: true
  };
  
  const stored = await browser.storage.sync.get(defaults);
  return stored;
}

// Add scene to Whisparr
async function addSceneToWhisparr(stashId) {
  const settings = await getSettings();
  
  if (!settings.whisparrUrl || !settings.apiKey) {
    throw new Error("Please configure Whisparr settings in extension options");
  }

  // Normalize the URL (remove trailing slash)
  const baseUrl = settings.whisparrUrl.replace(/\/$/, "");
  
  // First, lookup the scene from StashDB via Whisparr's lookup endpoint
  const lookupEndpoint = `${baseUrl}/api/v3/lookup/scene?term=${stashId}`;
  
  console.log("[StashDB-Whisparr] Looking up scene:", lookupEndpoint);
  
  const lookupResponse = await fetch(lookupEndpoint, {
    method: "GET",
    headers: {
      "X-Api-Key": settings.apiKey,
      "X-Requested-With": "XMLHttpRequest"
    }
  });

  if (!lookupResponse.ok) {
    const errorText = await lookupResponse.text();
    console.error("[StashDB-Whisparr] Lookup failed:", lookupResponse.status, errorText);
    throw new Error(`Lookup failed: ${lookupResponse.status} - ${errorText}`);
  }

  const lookupResults = await lookupResponse.json();
  console.log("[StashDB-Whisparr] Lookup results:", lookupResults);

  if (!lookupResults || lookupResults.length === 0) {
    throw new Error("Scene not found on StashDB");
  }

  // Get the first result - the scene data is in the 'movie' property
  const lookupResult = lookupResults[0];
  const sceneData = lookupResult.movie || lookupResult;
  
  console.log("[StashDB-Whisparr] Scene data:", sceneData);
  
  // Add required fields for the POST
  sceneData.monitored = settings.monitored;
  sceneData.qualityProfileId = parseInt(settings.qualityProfileId, 10);
  sceneData.rootFolderPath = settings.rootFolderPath;
  sceneData.addOptions = {
    monitor: "movieOnly",
    searchForMovie: settings.searchForMovie
  };

  // Now add the scene
  const addEndpoint = `${baseUrl}/api/v3/movie`;
  console.log("[StashDB-Whisparr] Adding scene:", addEndpoint, sceneData);

  const response = await fetch(addEndpoint, {
    method: "POST",
    headers: {
      "X-Api-Key": settings.apiKey,
      "Content-Type": "application/json",
      "X-Requested-With": "XMLHttpRequest"
    },
    body: JSON.stringify(sceneData)
  });

  if (!response.ok) {
    // Check if it's a 400 error (scene already exists)
    if (response.status === 400) {
      console.log("[StashDB-Whisparr] Scene already exists, checking for file...");
      // Pass the lookup result which may contain the movie ID
      return await handleExistingScene(baseUrl, settings.apiKey, stashId, settings.searchForMovie, lookupResult);
    }
    
    const errorText = await response.text();
    console.error("[StashDB-Whisparr] Add failed:", response.status, errorText);
    throw new Error(`Add failed: ${response.status} - ${errorText}`);
  }

  const result = await response.json();
  console.log("[StashDB-Whisparr] Scene added:", result);
  return result;
}

// Handle existing scene - check for file and optionally search
async function handleExistingScene(baseUrl, apiKey, stashId, searchForMovie, lookupResult) {
  let existingMovie = null;
  
  // Try to get the movie directly by ID from lookup result (fastest)
  if (lookupResult && lookupResult.movie && lookupResult.movie.id) {
    const movieId = lookupResult.movie.id;
    console.log("[StashDB-Whisparr] Fetching movie by ID:", movieId);
    
    const movieResponse = await fetch(`${baseUrl}/api/v3/movie/${movieId}`, {
      method: "GET",
      headers: {
        "X-Api-Key": apiKey,
        "X-Requested-With": "XMLHttpRequest"
      }
    });
    
    if (movieResponse.ok) {
      existingMovie = await movieResponse.json();
      console.log("[StashDB-Whisparr] Found movie by ID:", existingMovie.title);
    }
  }
  
  // Fallback: try querying by foreignId
  if (!existingMovie) {
    console.log("[StashDB-Whisparr] Trying to fetch by foreignId:", stashId);
    
    const movieResponse = await fetch(`${baseUrl}/api/v3/movie?foreignId=${stashId}`, {
      method: "GET",
      headers: {
        "X-Api-Key": apiKey,
        "X-Requested-With": "XMLHttpRequest"
      }
    });
    
    if (movieResponse.ok) {
      const movies = await movieResponse.json();
      if (Array.isArray(movies) && movies.length > 0) {
        existingMovie = movies[0];
        console.log("[StashDB-Whisparr] Found movie by foreignId:", existingMovie.title);
      }
    }
  }

  if (!existingMovie) {
    throw new Error("Scene exists in Whisparr but could not be found");
  }

  console.log("[StashDB-Whisparr] hasFile:", existingMovie.hasFile);

  // Check if the movie has a file
  if (existingMovie.hasFile) {
    throw new Error("File already exists");
  }

  // No file exists - trigger a search if enabled
  if (searchForMovie) {
    console.log("[StashDB-Whisparr] No file found, triggering search...");
    await triggerMovieSearch(baseUrl, apiKey, existingMovie.id);
    return { searched: true, movie: existingMovie };
  }

  throw new Error("Scene already in Whisparr but no file downloaded");
}

// Trigger a search for a specific movie
async function triggerMovieSearch(baseUrl, apiKey, movieId) {
  const commandEndpoint = `${baseUrl}/api/v3/command`;
  
  const response = await fetch(commandEndpoint, {
    method: "POST",
    headers: {
      "X-Api-Key": apiKey,
      "Content-Type": "application/json",
      "X-Requested-With": "XMLHttpRequest"
    },
    body: JSON.stringify({
      name: "MoviesSearch",
      movieIds: [movieId]
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error("[StashDB-Whisparr] Search command failed:", response.status, errorText);
    throw new Error(`Search command failed: ${response.status}`);
  }

  const result = await response.json();
  console.log("[StashDB-Whisparr] Search triggered:", result);
  return result;
}

// Show browser notification
function showNotification(title, message) {
  console.log("[StashDB-Whisparr] Showing notification:", title, "-", message);
  browser.notifications.create({
    type: "basic",
    iconUrl: browser.runtime.getURL("icons/icon-48.svg"),
    title: title,
    message: message
  }).then(() => {
    console.log("[StashDB-Whisparr] Notification created successfully");
  }).catch((err) => {
    console.error("[StashDB-Whisparr] Notification failed:", err);
  });
}

